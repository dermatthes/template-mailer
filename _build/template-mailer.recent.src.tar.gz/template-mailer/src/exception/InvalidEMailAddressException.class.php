<?php
/**
 * Created by PhpStorm.
 * User: matthes
 * Date: 21.07.15
 * Time: 13:23
 */


namespace de\leuffen\template_mailer\exception;


class InvalidEMailAddressException extends \Exception {

}