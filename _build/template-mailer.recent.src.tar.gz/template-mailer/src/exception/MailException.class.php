<?php
/**
 * Created by PhpStorm.
 * User: matthes
 * Date: 21.07.15
 * Time: 13:24
 */

namespace de\leuffen\template_mailer\exception;


class MailException extends \Exception {

}