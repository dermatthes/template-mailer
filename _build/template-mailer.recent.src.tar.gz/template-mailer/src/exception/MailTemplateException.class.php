<?php
/**
 * Created by PhpStorm.
 * User: matthes
 * Date: 21.07.15
 * Time: 19:29
 */

namespace de\leuffen\template_mailer\exception;

class MailTemplateException extends MailException {

}