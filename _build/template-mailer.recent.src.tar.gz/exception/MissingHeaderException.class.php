<?php
/**
 * Created by PhpStorm.
 * User: matthes
 * Date: 21.07.15
 * Time: 16:57
 */

namespace de\leuffen\template_mailer\exception;


class MissingHeaderException extends MailException {

}